public class Contrabaixo extends Corda {
    public Contrabaixo() {
        super("Contrabaixo");
    }
}
