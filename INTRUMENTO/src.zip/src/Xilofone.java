public class Xilofone extends Percussao {
    public Xilofone() {
        super("Xilofone");
    }
}
