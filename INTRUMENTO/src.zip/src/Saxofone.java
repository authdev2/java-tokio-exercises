public class Saxofone extends Sopro {
    public Saxofone() {
        super("Saxofone");
    }
}
