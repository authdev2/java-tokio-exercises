public class Violino extends Corda {
   public Violino() {
      super("Violino");
   }
}