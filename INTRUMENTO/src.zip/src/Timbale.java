public class Timbale extends Percussao {
    public Timbale() {
        super("Timbale");
    }
}
