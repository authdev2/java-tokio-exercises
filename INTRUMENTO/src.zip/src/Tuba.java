public class Tuba extends Sopro{
   public Tuba() {
      super("Tuba");
   }

}