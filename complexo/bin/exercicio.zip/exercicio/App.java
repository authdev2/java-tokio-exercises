public class App {
    public static void main(String[] args) throws Exception {
        NumeroComplexo a = new NumeroComplexo(10, 5);
        NumeroComplexo b = new NumeroComplexo(10, 2);

     System.out.println(NumeroComplexo.soma(a, b));


    }
}
