public interface CharSequenceTokio {
    int length();
    char charAt(int index);
    CharSequenceTokio subSequence(int start, int end);
    String toString();
}
