public class Figura3D extends Figura {
    private int z;
    public Figura3D(int x, int y, int z) {
        super(x, y);
        this.z = z;
    }

    public int getZ() {
        return z;
    }
}
