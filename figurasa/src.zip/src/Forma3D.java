public interface Forma3D {
    public void area();
    public void volume();
}
