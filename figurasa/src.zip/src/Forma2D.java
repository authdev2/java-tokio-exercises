public interface Forma2D {
    public void area();
    public void perimetro();
}
