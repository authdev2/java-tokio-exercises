public interface FormaCircular {
    public int getRaio();
}
